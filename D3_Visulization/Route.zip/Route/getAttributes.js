export const getAttributes = () => {

const attributes= [
{ value: 'casual', label: 'casual'},
{ value: 'member', label: 'member'},
{ value: 'Winter', label: 'Winter'},
{ value: 'Spring', label: 'Spring'},
{ value: 'Summer', label: 'Summer'},
{ value: 'Fall', label: 'Fall'}
 ]

return attributes;
}
